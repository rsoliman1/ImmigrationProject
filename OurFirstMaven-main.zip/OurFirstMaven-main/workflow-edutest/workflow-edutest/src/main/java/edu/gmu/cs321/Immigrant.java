package edu.gmu.cs321;

public class Immigrant {    
public static boolean checkANum (String anumid){
    return true;
}
}


