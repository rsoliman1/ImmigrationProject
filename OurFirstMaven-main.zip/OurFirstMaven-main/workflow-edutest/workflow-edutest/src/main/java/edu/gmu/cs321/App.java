package edu.gmu.cs321;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ImmigrantRev testrev = new ImmigrantRev();
        String aresult = testrev.getANumber();
        

    }
}
